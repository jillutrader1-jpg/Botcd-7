package com.example.voice

import android.content.Context
import android.speech.tts.TextToSpeech
import android.util.Log
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.Locale

sealed interface VoiceReadinessState {
    data object Checking : VoiceReadinessState
    data class Ready(val localeTag: String) : VoiceReadinessState
    data object LanguageMissing : VoiceReadinessState
    data class Error(val message: String) : VoiceReadinessState
}

class BengaliVoiceCoach(context: Context) {

    companion object {
        private const val TAG = "BengaliVoiceCoach"

        const val PHRASE_NO_CHART =
            "আমি কোন ট্রেডিং চার্ট দেখতে পাচ্ছি না, অনুগ্রহ করে একটি ট্রেডিং চার্ট খুলুন"
        const val PHRASE_ANALYZING_CHART =
            "হ্যাঁ, আমি ট্রেডিং চার্ট দেখতে পাচ্ছি এবং বিশ্লেষণ করছি, অনুগ্রহ করে অপেক্ষা করুন"
        const val PHRASE_STRONG_BUY =
            "নিশ্চিন্তে বাই ট্রেড করতে পারেন"
        const val PHRASE_STRONG_SELL =
            "নিশ্চিন্তে সেল ট্রেড করতে পারেন"
        const val PHRASE_WAIT =
            "মার্কেট এখন স্পষ্ট নয়, অনুগ্রহ করে অপেক্ষা করুন"
    }

    private val appContext = context.applicationContext
    private var tts: TextToSpeech? = null

    private val _readiness = MutableStateFlow<VoiceReadinessState>(VoiceReadinessState.Checking)
    val readiness: StateFlow<VoiceReadinessState> = _readiness.asStateFlow()

    init {
        initializeTts()
    }

    private fun initializeTts() {
        _readiness.value = VoiceReadinessState.Checking
        tts = TextToSpeech(appContext) { status ->
            if (status == TextToSpeech.SUCCESS) {
                configureBengaliLocale()
            } else {
                Log.e(TAG, "TextToSpeech init failed with status=$status")
                _readiness.value = VoiceReadinessState.Error("TTS engine unavailable")
            }
        }
    }

    private fun configureBengaliLocale() {
        val engine = tts ?: return
        val candidates = listOf(
            Locale.forLanguageTag("bn-BD"),
            Locale.forLanguageTag("bn-IN"),
            Locale.forLanguageTag("bn")
        )
        var selectedLocale: Locale? = null
        for (locale in candidates) {
            val support = engine.isLanguageAvailable(locale)
            if (support >= TextToSpeech.LANG_AVAILABLE) {
                val res = engine.setLanguage(locale)
                if (res != TextToSpeech.LANG_MISSING_DATA && res != TextToSpeech.LANG_NOT_SUPPORTED) {
                    selectedLocale = locale
                    break
                }
            }
        }

        if (selectedLocale != null) {
            engine.setSpeechRate(0.96f)
            engine.setPitch(1.0f)
            _readiness.value = VoiceReadinessState.Ready(selectedLocale.toLanguageTag())
            Log.d(TAG, "Bengali TTS ready with locale=${selectedLocale.toLanguageTag()}")
        } else {
            _readiness.value = VoiceReadinessState.LanguageMissing
            Log.w(TAG, "Bengali TTS voice pack not installed on device")
        }
    }

    fun refreshStatus() {
        val engine = tts
        if (engine == null) {
            initializeTts()
        } else {
            configureBengaliLocale()
        }
    }

    fun speakNoChart() = speak(PHRASE_NO_CHART, "no_chart")

    fun speakAnalyzingChart() = speak(PHRASE_ANALYZING_CHART, "analyzing_chart")

    fun speakStrongBuy() = speak(PHRASE_STRONG_BUY, "strong_buy")

    fun speakStrongSell() = speak(PHRASE_STRONG_SELL, "strong_sell")

    fun speakWait() = speak(PHRASE_WAIT, "wait")

    fun speakTestSample() = speak(PHRASE_ANALYZING_CHART, "test_sample")

    fun speak(text: String, utteranceId: String = "screen_ai_${System.currentTimeMillis()}") {
        val engine = tts ?: return
        try {
            engine.speak(text, TextToSpeech.QUEUE_FLUSH, null, utteranceId)
        } catch (e: Exception) {
            Log.e(TAG, "Failed to speak Bengali TTS", e)
        }
    }

    fun stopSpeaking() {
        runCatching { tts?.stop() }
    }

    fun release() {
        runCatching {
            tts?.stop()
            tts?.shutdown()
        }
        tts = null
    }
}
