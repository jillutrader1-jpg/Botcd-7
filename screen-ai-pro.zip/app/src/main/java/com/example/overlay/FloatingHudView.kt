package com.example.overlay

import android.animation.ValueAnimator
import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.SweepGradient
import android.graphics.Typeface
import android.view.MotionEvent
import android.view.View
import android.view.animation.LinearInterpolator
import androidx.core.content.res.ResourcesCompat
import com.example.R
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.hypot

@SuppressLint("ViewConstructor")
class FloatingHudView(
    context: Context,
    private val onDragDelta: (dx: Int, dy: Int) -> Unit,
    private val onCloseClicked: () -> Unit
) : View(context) {

    private var previewBitmap: Bitmap? = null
    private var currentPhase: HudPhase = HudPhase.INITIALIZING
    private var statusText: String = "INITIALIZING..."
    private var lastFrameTick = 0f

    private val density = resources.displayMetrics.density
    private val hudWidthPx = (164 * density).toInt()
    private val hudHeightPx = (242 * density).toInt()
    private val cornerRadius = 14f * density
    private val borderStroke = 3f * density

    private val monoTypeface: Typeface =
        ResourcesCompat.getFont(context, R.font.jetbrains_mono) ?: Typeface.MONOSPACE
    private val displayTypeface: Typeface =
        ResourcesCompat.getFont(context, R.font.space_grotesk) ?: Typeface.DEFAULT_BOLD

    private val timeFormat = SimpleDateFormat("HH:mm:ss", Locale.US)

    private val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#EA090C12")
        style = Paint.Style.FILL
    }
    private val previewFramePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#111722")
        style = Paint.Style.FILL
    }
    private val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = borderStroke
    }
    private val glowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = borderStroke * 2.2f
        alpha = 70
    }
    private val headerBrandPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#F1F5F9")
        textSize = 9.5f * density
        typeface = Typeface.create(displayTypeface, Typeface.BOLD)
        letterSpacing = 0.04f
    }
    private val clockPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#00E5FF")
        textSize = 9.5f * density
        typeface = Typeface.create(monoTypeface, Typeface.BOLD)
        textAlign = Paint.Align.RIGHT
    }
    private val statusBgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
    }
    private val statusTextPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textSize = 8.5f * density
        typeface = Typeface.create(monoTypeface, Typeface.BOLD)
        textAlign = Paint.Align.CENTER
    }
    private val closeCirclePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#E6161E2E")
        style = Paint.Style.FILL
    }
    private val closeStrokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#FF3B5C")
        style = Paint.Style.STROKE
        strokeWidth = 1.4f * density
    }
    private val closeXPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#F1F5F9")
        style = Paint.Style.STROKE
        strokeWidth = 1.8f * density
        strokeCap = Paint.Cap.ROUND
    }
    private val scanLinePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        strokeWidth = 2f * density
    }
    private val placeholderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#8B9BB4")
        textSize = 9f * density
        typeface = monoTypeface
        textAlign = Paint.Align.CENTER
    }
    private val bitmapPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)

    private val outerRect = RectF()
    private val previewRect = RectF()
    private val statusPillRect = RectF()
    private val closeTouchRect = RectF()
    private val closeVisualCenter = FloatArray(2)
    private val closeVisualRadius = 12.5f * density
    private val bitmapSrcRect = Rect()
    private val sweepMatrix = Matrix()

    private val rainbowColors = intArrayOf(
        Color.parseColor("#00E5FF"),
        Color.parseColor("#00E676"),
        Color.parseColor("#FFB300"),
        Color.parseColor("#FF3B5C"),
        Color.parseColor("#7C4DFF"),
        Color.parseColor("#00E5FF")
    )

    private var sweepPhase = 0f
    private val borderAnimator = ValueAnimator.ofFloat(0f, 360f).apply {
        duration = 2600L
        repeatCount = ValueAnimator.INFINITE
        interpolator = LinearInterpolator()
        addUpdateListener { anim ->
            sweepPhase = anim.animatedValue as Float
            lastFrameTick = (sweepPhase / 360f)
            invalidate()
        }
    }

    private var downRawX = 0f
    private var downRawY = 0f
    private var lastRawX = 0f
    private var lastRawY = 0f
    private var isDragging = false
    private var downInClose = false
    private val touchSlopPx = 6f * density

    init {
        contentDescription = context.getString(R.string.hud_brand_title)
        isClickable = true
        borderAnimator.start()
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        setMeasuredDimension(hudWidthPx, hudHeightPx)
    }

    fun updatePreviewBitmap(bitmap: Bitmap) {
        val previous = previewBitmap
        previewBitmap = bitmap
        if (previous != null && previous !== bitmap && !previous.isRecycled) {
            previous.recycle()
        }
        postInvalidateOnAnimation()
    }

    fun updateHudState(phase: HudPhase, label: String) {
        currentPhase = phase
        statusText = label
        postInvalidateOnAnimation()
    }

    fun cleanup() {
        borderAnimator.cancel()
        val bmp = previewBitmap
        previewBitmap = null
        if (bmp != null && !bmp.isRecycled) {
            bmp.recycle()
        }
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)

        val inset = borderStroke + 1.5f * density
        outerRect.set(inset, inset, width - inset, height - inset)

        // Background
        canvas.drawRoundRect(outerRect, cornerRadius, cornerRadius, bgPaint)

        // Header bar
        val headerBaseline = outerRect.top + 15f * density
        canvas.drawText("SCREEN AI PRO", outerRect.left + 8f * density, headerBaseline, headerBrandPaint)
        canvas.drawText(
            timeFormat.format(Date()),
            outerRect.right - 8f * density,
            headerBaseline,
            clockPaint
        )

        // Preview viewport
        val previewTop = outerRect.top + 21f * density
        val bottomAreaHeight = 32f * density
        val previewBottom = outerRect.bottom - bottomAreaHeight
        val padH = 6f * density
        previewRect.set(outerRect.left + padH, previewTop, outerRect.right - padH, previewBottom)
        canvas.drawRoundRect(previewRect, 8f * density, 8f * density, previewFramePaint)

        val bmp = previewBitmap
        if (bmp != null && !bmp.isRecycled) {
            canvas.save()
            val clipPath = android.graphics.Path().apply {
                addRoundRect(previewRect, 8f * density, 8f * density, android.graphics.Path.Direction.CW)
            }
            canvas.clipPath(clipPath)
            bitmapSrcRect.set(0, 0, bmp.width, bmp.height)
            canvas.drawBitmap(bmp, bitmapSrcRect, previewRect, bitmapPaint)

            if (currentPhase == HudPhase.ANALYZING || currentPhase == HudPhase.MONITORING) {
                val scanY = previewRect.top + previewRect.height() * lastFrameTick
                scanLinePaint.shader = LinearGradient(
                    previewRect.left,
                    scanY,
                    previewRect.right,
                    scanY,
                    intArrayOf(
                        Color.TRANSPARENT,
                        Color.parseColor("#CC00E5FF"),
                        Color.TRANSPARENT
                    ),
                    null,
                    Shader.TileMode.CLAMP
                )
                canvas.drawLine(previewRect.left, scanY, previewRect.right, scanY, scanLinePaint)
            }
            canvas.restore()
        } else {
            canvas.drawText(
                "LIVE FEED",
                previewRect.centerX(),
                previewRect.centerY() + 3f * density,
                placeholderPaint
            )
        }

        // Bottom controls: status pill + circular X button (with 48dp touch area)
        val bottomCenterY = outerRect.bottom - 16f * density
        val closeCenterX = outerRect.right - 16f * density
        closeVisualCenter[0] = closeCenterX
        closeVisualCenter[1] = bottomCenterY
        val halfTouch = 24f * density
        closeTouchRect.set(
            closeCenterX - halfTouch,
            bottomCenterY - halfTouch,
            closeCenterX + halfTouch,
            bottomCenterY + halfTouch
        )

        val pillRight = closeCenterX - closeVisualRadius - 6f * density
        statusPillRect.set(
            outerRect.left + 6f * density,
            bottomCenterY - 10.5f * density,
            pillRight,
            bottomCenterY + 10.5f * density
        )

        val (pillColor, pillTextColor) = resolveStatusColors(currentPhase)
        statusBgPaint.color = pillColor
        statusTextPaint.color = pillTextColor
        canvas.drawRoundRect(statusPillRect, 7f * density, 7f * density, statusBgPaint)

        val clippedLabel = ellipsizeToFit(statusText, statusPillRect.width() - 8f * density)
        val textY = statusPillRect.centerY() - (statusTextPaint.descent() + statusTextPaint.ascent()) / 2f
        canvas.drawText(clippedLabel, statusPillRect.centerX(), textY, statusTextPaint)

        // Close button visual
        canvas.drawCircle(closeCenterX, bottomCenterY, closeVisualRadius, closeCirclePaint)
        canvas.drawCircle(closeCenterX, bottomCenterY, closeVisualRadius, closeStrokePaint)
        val xHalf = 4.2f * density
        canvas.drawLine(
            closeCenterX - xHalf,
            bottomCenterY - xHalf,
            closeCenterX + xHalf,
            bottomCenterY + xHalf,
            closeXPaint
        )
        canvas.drawLine(
            closeCenterX - xHalf,
            bottomCenterY + xHalf,
            closeCenterX + xHalf,
            bottomCenterY - xHalf,
            closeXPaint
        )

        // Animated RGB or status-locked glowing border
        configureBorderShader()
        canvas.drawRoundRect(outerRect, cornerRadius, cornerRadius, glowPaint)
        canvas.drawRoundRect(outerRect, cornerRadius, cornerRadius, borderPaint)
    }

    private fun configureBorderShader() {
        val solidColor: Int? = when (currentPhase) {
            HudPhase.STRONG_BUY -> Color.parseColor("#00E676")
            HudPhase.STRONG_SELL, HudPhase.NO_CHART, HudPhase.COOLDOWN, HudPhase.ERROR ->
                Color.parseColor("#FF3B5C")
            HudPhase.WAIT -> Color.parseColor("#FFB300")
            HudPhase.IDLE, HudPhase.INITIALIZING, HudPhase.MONITORING, HudPhase.ANALYZING -> null
        }

        if (solidColor != null) {
            borderPaint.shader = null
            borderPaint.color = solidColor
            glowPaint.shader = null
            glowPaint.color = solidColor
            glowPaint.alpha = 80
        } else {
            val sweep = SweepGradient(outerRect.centerX(), outerRect.centerY(), rainbowColors, null)
            sweepMatrix.setRotate(sweepPhase, outerRect.centerX(), outerRect.centerY())
            sweep.setLocalMatrix(sweepMatrix)
            borderPaint.shader = sweep
            glowPaint.shader = sweep
            glowPaint.alpha = 70
        }
    }

    private fun resolveStatusColors(phase: HudPhase): Pair<Int, Int> {
        return when (phase) {
            HudPhase.STRONG_BUY -> Color.parseColor("#00E676") to Color.parseColor("#041016")
            HudPhase.STRONG_SELL -> Color.parseColor("#FF3B5C") to Color.WHITE
            HudPhase.NO_CHART, HudPhase.COOLDOWN, HudPhase.ERROR ->
                Color.parseColor("#CCFF3B5C") to Color.WHITE
            HudPhase.WAIT -> Color.parseColor("#FFB300") to Color.parseColor("#041016")
            HudPhase.ANALYZING -> Color.parseColor("#241447") to Color.parseColor("#00E5FF")
            HudPhase.MONITORING, HudPhase.INITIALIZING, HudPhase.IDLE ->
                Color.parseColor("#161E2E") to Color.parseColor("#00E5FF")
        }
    }

    private fun ellipsizeToFit(text: String, maxWidth: Float): String {
        if (maxWidth <= 0f || statusTextPaint.measureText(text) <= maxWidth) return text
        var end = text.length
        while (end > 1 && statusTextPaint.measureText(text.substring(0, end) + "…") > maxWidth) {
            end--
        }
        return text.substring(0, end) + "…"
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downRawX = event.rawX
                downRawY = event.rawY
                lastRawX = event.rawX
                lastRawY = event.rawY
                isDragging = false
                downInClose = closeTouchRect.contains(event.x, event.y)
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                val totalMove = hypot(event.rawX - downRawX, event.rawY - downRawY)
                if (!isDragging && totalMove > touchSlopPx) {
                    isDragging = true
                }
                if (isDragging) {
                    val dx = (event.rawX - lastRawX).toInt()
                    val dy = (event.rawY - lastRawY).toInt()
                    lastRawX = event.rawX
                    lastRawY = event.rawY
                    if (dx != 0 || dy != 0) {
                        onDragDelta(dx, dy)
                    }
                }
                return true
            }
            MotionEvent.ACTION_UP -> {
                if (!isDragging && downInClose && closeTouchRect.contains(event.x, event.y)) {
                    onCloseClicked()
                }
                return true
            }
        }
        return super.onTouchEvent(event)
    }
}
