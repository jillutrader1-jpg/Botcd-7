package com.example.overlay

import android.app.Activity
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.graphics.Rect
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.util.DisplayMetrics
import android.util.Log
import android.view.Gravity
import android.view.WindowManager
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import com.example.MainActivity
import com.example.R
import com.example.ai.ChartSignalType
import com.example.ai.ChartVisionAnalyzer
import com.example.data.local.AppDatabase
import com.example.data.local.EnginePreferences
import com.example.data.local.SignalRecordEntity
import com.example.data.local.SignalRepository
import com.example.data.local.UserPreferencesRepository
import com.example.voice.BengaliVoiceCoach
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.util.concurrent.atomic.AtomicReference

class ScreenAiForegroundService : Service() {

    companion object {
        private const val TAG = "ScreenAiService"
        private const val NOTIFICATION_ID = 4101

        const val ACTION_START = "com.example.action.START_SCREEN_AI"
        const val ACTION_STOP = "com.example.action.STOP_SCREEN_AI"
        const val EXTRA_RESULT_CODE = "extra_result_code"
        const val EXTRA_RESULT_DATA = "extra_result_data"

        private const val PREVIEW_THROTTLE_MS = 130L
        private const val NO_CHART_VOICE_REMINDER_MS = 28_000L

        private val ANALYSIS_STAGES = listOf(
            "ANALYZING SMA...",
            "ANALYZING BOLLINGER...",
            "ANALYZING VOLUME...",
            "ANALYZING RSI...",
            "ANALYZING STOCHASTIC..."
        )
    }

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private lateinit var windowManager: WindowManager
    private lateinit var notificationManager: NotificationManager
    private lateinit var voiceCoach: BengaliVoiceCoach
    private lateinit var signalRepository: SignalRepository
    private lateinit var prefsRepository: UserPreferencesRepository
    private lateinit var visionAnalyzer: ChartVisionAnalyzer

    private var overlayView: FloatingHudView? = null
    private var overlayParams: WindowManager.LayoutParams? = null

    private var mediaProjection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null
    private var captureThread: HandlerThread? = null
    private var captureHandler: Handler? = null
    private val mainHandler = Handler(Looper.getMainLooper())

    private var captureWidth = 720
    private var captureHeight = 1280
    private var captureDensity = DisplayMetrics.DENSITY_DEFAULT

    private val latestCapturedFrame = AtomicReference<Bitmap?>(null)
    private var lastPreviewUpdateMs = 0L
    private var monitorJob: Job? = null
    private var currentPrefs = EnginePreferences()

    private val projectionCallback = object : MediaProjection.Callback() {
        override fun onStop() {
            Log.i(TAG, "MediaProjection stopped by system or user status chip.")
            mainHandler.post { stopSelfSafely() }
        }

        override fun onCapturedContentResize(width: Int, height: Int) {
            if (width > 0 && height > 0 && (width != captureWidth || height != captureHeight)) {
                Log.d(TAG, "Captured content resized to ${width}x$height")
                captureWidth = width
                captureHeight = height
                recreateImageReader(width, height)
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WindowManager::class.java)
        notificationManager = getSystemService(NotificationManager::class.java)
        voiceCoach = BengaliVoiceCoach(this)
        signalRepository = SignalRepository(AppDatabase.getInstance(this).signalRecordDao())
        prefsRepository = UserPreferencesRepository(this)
        visionAnalyzer = ChartVisionAnalyzer(this)

        serviceScope.launch {
            prefsRepository.preferences.collect { prefs ->
                currentPrefs = prefs
            }
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                stopSelfSafely()
                return START_NOT_STICKY
            }
            ACTION_START -> {
                val resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, Activity.RESULT_CANCELED)
                val resultData: Intent? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    intent.getParcelableExtra(EXTRA_RESULT_DATA, Intent::class.java)
                } else {
                    @Suppress("DEPRECATION")
                    intent.getParcelableExtra(EXTRA_RESULT_DATA)
                }

                if (resultCode != Activity.RESULT_OK || resultData == null) {
                    Log.e(TAG, "Missing valid MediaProjection grant.")
                    stopSelfSafely()
                    return START_NOT_STICKY
                }

                startMonitoringSession(resultCode, resultData)
            }
        }
        return START_NOT_STICKY
    }

    private fun startMonitoringSession(resultCode: Int, resultData: Intent) {
        createNotificationChannel()
        val notification = buildNotification(getString(R.string.notif_text_monitoring))
        val fgsType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
        } else {
            0
        }
        ServiceCompat.startForeground(this, NOTIFICATION_ID, notification, fgsType)

        if (!Settings.canDrawOverlays(this)) {
            OverlayRuntimeHub.update {
                it.copy(
                    isRunning = false,
                    phase = HudPhase.ERROR,
                    statusLabel = "NO OVERLAY PERM",
                    errorMessage = "Overlay permission is required."
                )
            }
            stopSelfSafely()
            return
        }

        val projectionManager = getSystemService(MediaProjectionManager::class.java)
        val projection = projectionManager.getMediaProjection(resultCode, resultData)
        if (projection == null) {
            OverlayRuntimeHub.update {
                it.copy(
                    isRunning = false,
                    phase = HudPhase.ERROR,
                    statusLabel = "CAPTURE FAILED",
                    errorMessage = "Could not obtain MediaProjection."
                )
            }
            stopSelfSafely()
            return
        }

        stopProjectionResourcesOnly()
        mediaProjection = projection
        projection.registerCallback(projectionCallback, mainHandler)

        resolveCaptureBounds()
        setupVirtualDisplay(projection)
        attachOverlayWindow()
        startAutoAnalysisLoop()
    }

    private fun resolveCaptureBounds() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            val bounds = windowManager.maximumWindowMetrics.bounds
            captureWidth = bounds.width().coerceAtLeast(360)
            captureHeight = bounds.height().coerceAtLeast(640)
            captureDensity = resources.configuration.densityDpi
        } else {
            val metrics = DisplayMetrics()
            @Suppress("DEPRECATION")
            windowManager.defaultDisplay.getRealMetrics(metrics)
            captureWidth = metrics.widthPixels.coerceAtLeast(360)
            captureHeight = metrics.heightPixels.coerceAtLeast(640)
            captureDensity = metrics.densityDpi
        }
    }

    private fun setupVirtualDisplay(projection: MediaProjection) {
        val thread = HandlerThread("ScreenAiCapture").apply { start() }
        captureThread = thread
        val handler = Handler(thread.looper)
        captureHandler = handler

        val reader = ImageReader.newInstance(captureWidth, captureHeight, PixelFormat.RGBA_8888, 2)
        imageReader = reader
        reader.setOnImageAvailableListener({ r -> processAvailableImage(r) }, handler)

        virtualDisplay = projection.createVirtualDisplay(
            "ScreenAiProDisplay",
            captureWidth,
            captureHeight,
            captureDensity,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            reader.surface,
            null,
            handler
        )
    }

    private fun recreateImageReader(width: Int, height: Int) {
        val handler = captureHandler ?: return
        imageReader?.close()
        val newReader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2)
        imageReader = newReader
        newReader.setOnImageAvailableListener({ r -> processAvailableImage(r) }, handler)
        virtualDisplay?.resize(width, height, captureDensity)
        virtualDisplay?.surface = newReader.surface
    }

    private fun processAvailableImage(reader: ImageReader) {
        var image: Image? = null
        try {
            image = reader.acquireLatestImage() ?: return
            val now = System.currentTimeMillis()
            if (now - lastPreviewUpdateMs < PREVIEW_THROTTLE_MS) {
                return
            }
            lastPreviewUpdateMs = now

            val bitmap = imageToBitmap(image) ?: return
            val prev = latestCapturedFrame.getAndSet(bitmap)
            if (prev != null && !prev.isRecycled) {
                prev.recycle()
            }

            // Create a lightweight preview copy for the HUD View.
            val previewWidth = 220
            val previewHeight = ((bitmap.height.toFloat() / bitmap.width.toFloat()) * previewWidth)
                .toInt().coerceAtLeast(1)
            val previewCopy = Bitmap.createScaledBitmap(bitmap, previewWidth, previewHeight, true)
            overlayView?.post {
                overlayView?.updatePreviewBitmap(previewCopy)
            }
        } catch (e: Exception) {
            Log.w(TAG, "Frame capture skipped: ${e.message}")
        } finally {
            image?.close()
        }
    }

    private fun imageToBitmap(image: Image): Bitmap? {
        val planes = image.planes
        if (planes.isEmpty()) return null
        val buffer = planes[0].buffer
        val pixelStride = planes[0].pixelStride
        val rowStride = planes[0].rowStride
        val rowPadding = rowStride - pixelStride * image.width
        val paddedWidth = image.width + rowPadding / pixelStride
        val fullBitmap = Bitmap.createBitmap(paddedWidth, image.height, Bitmap.Config.ARGB_8888)
        fullBitmap.copyPixelsFromBuffer(buffer)
        return if (paddedWidth == image.width) {
            fullBitmap
        } else {
            val cropped = Bitmap.createBitmap(fullBitmap, 0, 0, image.width, image.height)
            fullBitmap.recycle()
            cropped
        }
    }

    private fun attachOverlayWindow() {
        if (overlayView != null) return

        val layoutType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            layoutType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.END
            x = (16 * resources.displayMetrics.density).toInt()
            y = (140 * resources.displayMetrics.density).toInt()
        }

        val view = FloatingHudView(
            context = this,
            onDragDelta = { dx, dy ->
                val p = overlayParams ?: return@FloatingHudView
                // Gravity is TOP|END, so moving finger right increases screen X and decreases END offset.
                p.x -= dx
                p.y += dy
                runCatching { windowManager.updateViewLayout(overlayView, p) }
            },
            onCloseClicked = { stopSelfSafely() }
        )

        overlayParams = params
        overlayView = view
        windowManager.addView(view, params)
    }

    private fun getOverlayScreenRect(): Rect? {
        val view = overlayView ?: return null
        if (!view.isAttachedToWindow || view.width == 0 || view.height == 0) return null
        val loc = IntArray(2)
        view.getLocationOnScreen(loc)
        return Rect(loc[0], loc[1], loc[0] + view.width, loc[1] + view.height)
    }

    private fun startAutoAnalysisLoop() {
        monitorJob?.cancel()
        monitorJob = serviceScope.launch {
            currentPrefs = prefsRepository.preferences.first()
            updateHud(HudPhase.INITIALIZING, "INITIALIZING...")
            delay(1_200L)

            var lastPhaseWasNoChart = false
            var lastNoChartSpokenAtMs = 0L

            while (isActive) {
                updateHud(HudPhase.MONITORING, "MONITORING MARKET")
                val snapshot = awaitFreshBitmapCopy()
                if (snapshot == null) {
                    delay(800L)
                    continue
                }

                val overlayRect = getOverlayScreenRect()
                val initialCheck = visionAnalyzer.analyzeScreen(snapshot, overlayRect)
                if (!snapshot.isRecycled) snapshot.recycle()

                if (initialCheck.isFailure) {
                    val msg = initialCheck.exceptionOrNull()?.localizedMessage
                        ?: "AI Vision check failed"
                    val shortCode = when {
                        msg.contains("google-services.json", ignoreCase = true) ||
                            msg.contains("not initialized", ignoreCase = true) -> "ERR: NO CONFIG"
                        msg.contains("timeout", ignoreCase = true) ||
                            msg.contains("timed out", ignoreCase = true) -> "ERR: TIMEOUT"
                        msg.contains("403", ignoreCase = true) ||
                            msg.contains("attestation", ignoreCase = true) ||
                            msg.contains("app check", ignoreCase = true) -> "ERR: APP CHECK"
                        msg.contains("429", ignoreCase = true) ||
                            msg.contains("quota", ignoreCase = true) -> "ERR: QUOTA"
                        msg.contains("network", ignoreCase = true) ||
                            msg.contains("unable to resolve host", ignoreCase = true) ||
                            msg.contains("connect", ignoreCase = true) -> "ERR: NO NET"
                        else -> "AI ERROR"
                    }
                    updateHud(HudPhase.ERROR, shortCode, error = msg)
                    delay(4_000L)
                    continue
                }

                val detection = initialCheck.getOrThrow()
                if (!detection.hasTradingChart || detection.signal == ChartSignalType.NO_CHART) {
                    updateHud(HudPhase.NO_CHART, "NO CHART")
                    val now = System.currentTimeMillis()
                    if (currentPrefs.voiceEnabled &&
                        (!lastPhaseWasNoChart || now - lastNoChartSpokenAtMs >= NO_CHART_VOICE_REMINDER_MS)
                    ) {
                        voiceCoach.speakNoChart()
                        lastNoChartSpokenAtMs = now
                    }
                    lastPhaseWasNoChart = true
                    delay(currentPrefs.scanIntervalSeconds * 1_000L)
                    continue
                }

                // Chart detected! Announce in Bengali & run indicator verification stages.
                lastPhaseWasNoChart = false
                if (currentPrefs.voiceEnabled) {
                    voiceCoach.speakAnalyzingChart()
                }

                for (stage in ANALYSIS_STAGES) {
                    if (!isActive) break
                    updateHud(HudPhase.ANALYZING, stage)
                    delay(750L)
                }

                // Deliver Signal
                val finalPhase: HudPhase
                val finalLabel: String
                when (detection.signal) {
                    ChartSignalType.STRONG_BUY -> {
                        finalPhase = HudPhase.STRONG_BUY
                        finalLabel = "STRONG BUY"
                        if (currentPrefs.voiceEnabled) voiceCoach.speakStrongBuy()
                    }
                    ChartSignalType.STRONG_SELL -> {
                        finalPhase = HudPhase.STRONG_SELL
                        finalLabel = "STRONG SELL"
                        if (currentPrefs.voiceEnabled) voiceCoach.speakStrongSell()
                    }
                    ChartSignalType.WAIT, ChartSignalType.NO_CHART -> {
                        finalPhase = HudPhase.WAIT
                        finalLabel = "WAIT / NEUTRAL"
                        if (currentPrefs.voiceEnabled) voiceCoach.speakWait()
                    }
                }

                updateHud(
                    phase = finalPhase,
                    label = finalLabel,
                    assetPair = detection.assetPair,
                    confidence = detection.confidencePercent,
                    summary = detection.indicatorSummary
                )
                updateNotification("$finalLabel • ${detection.assetPair}")

                // Persist signal to Room history log
                signalRepository.recordSignal(
                    SignalRecordEntity(
                        signalType = detection.signal.name,
                        assetPair = detection.assetPair,
                        timeframe = detection.timeframe,
                        confidencePercent = detection.confidencePercent,
                        indicatorSummary = detection.indicatorSummary,
                        rationale = detection.rationale
                    )
                )

                // Hold the signal banner on screen briefly before entering AI OFF cooldown
                delay(4_500L)

                // Cooldown ("AI OFF" state matching video)
                val cooldownSec = currentPrefs.cooldownSeconds
                for (remaining in cooldownSec downTo 1) {
                    if (!isActive) break
                    updateHud(
                        phase = HudPhase.COOLDOWN,
                        label = "AI OFF",
                        cooldownRemainingSec = remaining
                    )
                    delay(1_000L)
                }
                updateNotification(getString(R.string.notif_text_monitoring))
            }
        }
    }

    private suspend fun awaitFreshBitmapCopy(): Bitmap? = kotlinx.coroutines.withContext(Dispatchers.Default) {
        for (attempt in 0..8) {
            val bmp = latestCapturedFrame.get()
            if (bmp != null && !bmp.isRecycled) {
                return@withContext try {
                    bmp.copy(Bitmap.Config.ARGB_8888, false)
                } catch (_: Exception) {
                    null
                }
            }
            delay(200L)
        }
        null
    }

    private fun updateHud(
        phase: HudPhase,
        label: String,
        assetPair: String? = null,
        confidence: Int? = null,
        summary: String? = null,
        cooldownRemainingSec: Int = 0,
        error: String? = null
    ) {
        overlayView?.updateHudState(phase, label)
        OverlayRuntimeHub.update { prev ->
            prev.copy(
                isRunning = true,
                phase = phase,
                statusLabel = label,
                lastAssetPair = assetPair ?: prev.lastAssetPair,
                lastConfidence = confidence ?: prev.lastConfidence,
                lastSummary = summary ?: prev.lastSummary,
                cooldownRemainingSec = cooldownRemainingSec,
                errorMessage = error
            )
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                getString(R.string.notif_channel_id),
                getString(R.string.notif_channel_name),
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = getString(R.string.notif_text_monitoring)
            }
            notificationManager.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(contentText: String): Notification {
        val openIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val openPending = PendingIntent.getActivity(
            this,
            0,
            openIntent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val stopIntent = Intent(this, ScreenAiForegroundService::class.java).apply {
            action = ACTION_STOP
        }
        val stopPending = PendingIntent.getService(
            this,
            1,
            stopIntent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        return NotificationCompat.Builder(this, getString(R.string.notif_channel_id))
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle(getString(R.string.notif_title))
            .setContentText(contentText)
            .setContentIntent(openPending)
            .setOngoing(true)
            .addAction(0, getString(R.string.notif_action_stop), stopPending)
            .build()
    }

    private fun updateNotification(text: String) {
        runCatching {
            notificationManager.notify(NOTIFICATION_ID, buildNotification(text))
        }
    }

    private fun stopProjectionResourcesOnly() {
        runCatching { virtualDisplay?.release() }
        virtualDisplay = null
        runCatching { imageReader?.close() }
        imageReader = null
        runCatching {
            mediaProjection?.unregisterCallback(projectionCallback)
            mediaProjection?.stop()
        }
        mediaProjection = null
        runCatching { captureThread?.quitSafely() }
        captureThread = null
        captureHandler = null
        latestCapturedFrame.getAndSet(null)?.let { if (!it.isRecycled) it.recycle() }
    }

    private fun stopSelfSafely() {
        monitorJob?.cancel()
        monitorJob = null
        overlayView?.let { view ->
            runCatching { windowManager.removeView(view) }
            view.cleanup()
        }
        overlayView = null
        overlayParams = null
        stopProjectionResourcesOnly()
        voiceCoach.stopSpeaking()
        OverlayRuntimeHub.reset()
        ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        monitorJob?.cancel()
        serviceScope.cancel()
        overlayView?.let { view ->
            runCatching { windowManager.removeView(view) }
            view.cleanup()
        }
        overlayView = null
        stopProjectionResourcesOnly()
        voiceCoach.release()
        OverlayRuntimeHub.reset()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
