package com.example.overlay

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

enum class HudPhase {
    IDLE,
    INITIALIZING,
    NO_CHART,
    MONITORING,
    ANALYZING,
    STRONG_BUY,
    STRONG_SELL,
    WAIT,
    COOLDOWN,
    ERROR
}

data class OverlayRuntimeState(
    val isRunning: Boolean = false,
    val phase: HudPhase = HudPhase.IDLE,
    val statusLabel: String = "AI OFF",
    val lastAssetPair: String = "",
    val lastConfidence: Int = 0,
    val lastSummary: String = "",
    val cooldownRemainingSec: Int = 0,
    val errorMessage: String? = null
)

object OverlayRuntimeHub {
    private val _state = MutableStateFlow(OverlayRuntimeState())
    val state: StateFlow<OverlayRuntimeState> = _state.asStateFlow()

    fun update(transform: (OverlayRuntimeState) -> OverlayRuntimeState) {
        _state.value = transform(_state.value)
    }

    fun reset() {
        _state.value = OverlayRuntimeState()
    }
}
