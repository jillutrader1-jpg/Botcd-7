package com.example.data.local

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "screen_ai_prefs")

data class EnginePreferences(
    val voiceEnabled: Boolean = true,
    val scanIntervalSeconds: Int = 5,
    val cooldownSeconds: Int = 35
)

class UserPreferencesRepository(private val context: Context) {

    private object Keys {
        val VOICE_ENABLED = booleanPreferencesKey("voice_enabled")
        val SCAN_INTERVAL_SECONDS = intPreferencesKey("scan_interval_seconds")
        val COOLDOWN_SECONDS = intPreferencesKey("cooldown_seconds")
    }

    val preferences: Flow<EnginePreferences> = context.dataStore.data.map { prefs ->
        EnginePreferences(
            voiceEnabled = prefs[Keys.VOICE_ENABLED] ?: true,
            scanIntervalSeconds = prefs[Keys.SCAN_INTERVAL_SECONDS] ?: 5,
            cooldownSeconds = prefs[Keys.COOLDOWN_SECONDS] ?: 35
        )
    }

    suspend fun setVoiceEnabled(enabled: Boolean) {
        context.dataStore.edit { it[Keys.VOICE_ENABLED] = enabled }
    }

    suspend fun setScanIntervalSeconds(seconds: Int) {
        context.dataStore.edit { it[Keys.SCAN_INTERVAL_SECONDS] = seconds.coerceIn(3, 30) }
    }

    suspend fun setCooldownSeconds(seconds: Int) {
        context.dataStore.edit { it[Keys.COOLDOWN_SECONDS] = seconds.coerceIn(10, 120) }
    }
}
