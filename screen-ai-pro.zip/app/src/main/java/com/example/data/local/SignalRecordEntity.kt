package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "signal_records")
data class SignalRecordEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0L,
    val timestampMillis: Long = System.currentTimeMillis(),
    val signalType: String,
    val assetPair: String,
    val timeframe: String,
    val confidencePercent: Int,
    val indicatorSummary: String,
    val rationale: String
)
