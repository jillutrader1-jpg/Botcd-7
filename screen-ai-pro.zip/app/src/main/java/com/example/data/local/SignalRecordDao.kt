package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface SignalRecordDao {
    @Query("SELECT * FROM signal_records ORDER BY timestampMillis DESC")
    fun getAllSignals(): Flow<List<SignalRecordEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSignal(record: SignalRecordEntity)

    @Query("DELETE FROM signal_records WHERE id = :id")
    suspend fun deleteById(id: Long)

    @Query("DELETE FROM signal_records")
    suspend fun clearAll()
}
