package com.example.data.local

import kotlinx.coroutines.flow.Flow

class SignalRepository(private val dao: SignalRecordDao) {
    val allSignals: Flow<List<SignalRecordEntity>> = dao.getAllSignals()

    suspend fun recordSignal(record: SignalRecordEntity) {
        dao.insertSignal(record)
    }

    suspend fun deleteSignal(id: Long) {
        dao.deleteById(id)
    }

    suspend fun clearAll() {
        dao.clearAll()
    }
}
