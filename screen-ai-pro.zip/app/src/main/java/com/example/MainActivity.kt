package com.example

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionConfig
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.History
import androidx.compose.material.icons.outlined.Tune
import androidx.compose.material.icons.rounded.History
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.ai.configureAppCheck
import com.example.overlay.ScreenAiForegroundService
import com.example.ui.screens.ControlHubScreen
import com.example.ui.screens.SignalHistoryScreen
import com.example.ui.theme.CharcoalSurface
import com.example.ui.theme.ElectricCyan
import com.example.ui.theme.ObsidianBg
import com.example.ui.theme.ScreenAiProTheme
import com.example.ui.theme.SteelMuted
import com.example.ui.viewmodel.MainViewModel
import kotlinx.coroutines.launch

const val ROUTE_CONTROL_HUB = "control_hub"
const val ROUTE_SIGNAL_HISTORY = "signal_history"

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // STEP 1: Configure App Check with launch intent before any UI, ViewModels, or Firebase operations.
        configureAppCheck(this, intent)

        enableEdgeToEdge()
        setContent {
            ScreenAiProTheme {
                ScreenAiApp()
            }
        }
    }
}

@Composable
fun ScreenAiApp(viewModel: MainViewModel = viewModel()) {
    val context = LocalContext.current
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val navController = rememberNavController()
    val snackbarHostState = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()

    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) {
        viewModel.refreshSystemChecks()
    }

    val mediaProjectionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val data = result.data
        if (result.resultCode == Activity.RESULT_OK && data != null) {
            val serviceIntent = Intent(context, ScreenAiForegroundService::class.java).apply {
                action = ScreenAiForegroundService.ACTION_START
                putExtra(ScreenAiForegroundService.EXTRA_RESULT_CODE, result.resultCode)
                putExtra(ScreenAiForegroundService.EXTRA_RESULT_DATA, data)
            }
            ContextCompat.startForegroundService(context, serviceIntent)
        } else {
            scope.launch {
                snackbarHostState.showSnackbar("Screen capture permission was cancelled.")
            }
        }
    }

    fun requestMediaProjection() {
        val manager = context.getSystemService(MediaProjectionManager::class.java)
        val captureIntent = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            manager.createScreenCaptureIntent(
                MediaProjectionConfig.createConfigForDefaultDisplay()
            )
        } else {
            manager.createScreenCaptureIntent()
        }
        mediaProjectionLauncher.launch(captureIntent)
    }

    val notificationPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        viewModel.refreshSystemChecks()
        if (granted && Settings.canDrawOverlays(context)) {
            requestMediaProjection()
        } else if (!granted) {
            scope.launch {
                snackbarHostState.showSnackbar("Notification permission keeps Screen AI Pro active.")
            }
        }
    }

    val openOverlaySettings: () -> Unit = {
        val intent = Intent(
            Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
            Uri.parse("package:${context.packageName}")
        )
        context.startActivity(intent)
    }

    val requestNotificationPerm: () -> Unit = {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    val handleLaunchHud: () -> Unit = {
        when {
            !Settings.canDrawOverlays(context) -> {
                scope.launch {
                    snackbarHostState.showSnackbar("Enable 'Display over other apps' for Screen AI Pro.")
                }
                openOverlaySettings()
            }
            !uiState.hasNotificationPermission &&
                Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU -> {
                requestNotificationPerm()
            }
            else -> requestMediaProjection()
        }
    }

    val handleStopHud: () -> Unit = {
        val stopIntent = Intent(context, ScreenAiForegroundService::class.java).apply {
            action = ScreenAiForegroundService.ACTION_STOP
        }
        context.startService(stopIntent)
    }

    val backStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = backStackEntry?.destination?.route ?: ROUTE_CONTROL_HUB

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        containerColor = ObsidianBg,
        contentWindowInsets = WindowInsets.safeDrawing,
        snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
        bottomBar = {
            NavigationBar(
                containerColor = CharcoalSurface
            ) {
                NavigationBarItem(
                    selected = currentRoute == ROUTE_CONTROL_HUB,
                    onClick = {
                        navController.navigate(ROUTE_CONTROL_HUB) {
                            popUpTo(ROUTE_CONTROL_HUB) { saveState = true }
                            launchSingleTop = true
                            restoreState = true
                        }
                    },
                    icon = {
                        Icon(
                            imageVector = if (currentRoute == ROUTE_CONTROL_HUB) {
                                Icons.Rounded.Tune
                            } else {
                                Icons.Outlined.Tune
                            },
                            contentDescription = stringResource(R.string.nav_control_hub)
                        )
                    },
                    label = { Text(stringResource(R.string.nav_control_hub)) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = ElectricCyan,
                        selectedTextColor = ElectricCyan,
                        indicatorColor = ElectricCyan.copy(alpha = 0.16f),
                        unselectedIconColor = SteelMuted,
                        unselectedTextColor = SteelMuted
                    ),
                    modifier = Modifier.testTag("nav_control_hub")
                )

                NavigationBarItem(
                    selected = currentRoute == ROUTE_SIGNAL_HISTORY,
                    onClick = {
                        navController.navigate(ROUTE_SIGNAL_HISTORY) {
                            popUpTo(ROUTE_CONTROL_HUB) { saveState = true }
                            launchSingleTop = true
                            restoreState = true
                        }
                    },
                    icon = {
                        Icon(
                            imageVector = if (currentRoute == ROUTE_SIGNAL_HISTORY) {
                                Icons.Rounded.History
                            } else {
                                Icons.Outlined.History
                            },
                            contentDescription = stringResource(R.string.nav_signal_history)
                        )
                    },
                    label = { Text(stringResource(R.string.nav_signal_history)) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = ElectricCyan,
                        selectedTextColor = ElectricCyan,
                        indicatorColor = ElectricCyan.copy(alpha = 0.16f),
                        unselectedIconColor = SteelMuted,
                        unselectedTextColor = SteelMuted
                    ),
                    modifier = Modifier.testTag("nav_signal_history")
                )
            }
        }
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = ROUTE_CONTROL_HUB,
            modifier = Modifier.padding(innerPadding)
        ) {
            composable(ROUTE_CONTROL_HUB) {
                ControlHubScreen(
                    uiState = uiState,
                    onLaunchHud = handleLaunchHud,
                    onStopHud = handleStopHud,
                    onRequestOverlayPermission = openOverlaySettings,
                    onRequestNotificationPermission = requestNotificationPerm,
                    onTestVoice = { viewModel.testBengaliVoice() },
                    onOpenTtsSettings = {
                        runCatching {
                            context.startActivity(Intent("com.android.settings.TTS_SETTINGS"))
                        }
                    },
                    onVoiceToggle = { viewModel.setVoiceEnabled(it) },
                    onScanIntervalChange = { viewModel.setScanInterval(it) },
                    onCooldownChange = { viewModel.setCooldownSeconds(it) }
                )
            }
            composable(ROUTE_SIGNAL_HISTORY) {
                SignalHistoryScreen(
                    uiState = uiState,
                    onFilterSelected = { viewModel.setSignalFilter(it) },
                    onDeleteSignal = { viewModel.deleteSignal(it) },
                    onClearAll = { viewModel.clearHistory() }
                )
            }
        }
    }
}
