package com.example.ai

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.util.Log
import com.google.firebase.Firebase
import com.google.firebase.ai.ai
import com.google.firebase.ai.type.Schema
import com.google.firebase.ai.type.content
import com.google.firebase.ai.type.generationConfig
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeout
import org.json.JSONObject

enum class ChartSignalType {
    NO_CHART,
    STRONG_BUY,
    STRONG_SELL,
    WAIT
}

data class ChartAnalysisResult(
    val hasTradingChart: Boolean,
    val signal: ChartSignalType,
    val assetPair: String,
    val timeframe: String,
    val confidencePercent: Int,
    val indicatorSummary: String,
    val rationale: String
)

class ChartVisionAnalyzer(context: android.content.Context) {

    private val appContext = context.applicationContext

    companion object {
        private const val TAG = "ChartVisionAnalyzer"
        private const val MODEL_NAME = "gemini-3.8-flash"
        private const val TIMEOUT_MS = 60_000L
        private const val MAX_DIMENSION_PX = 640
    }

    private val responseSchema = Schema.obj(
        properties = mapOf(
            "hasTradingChart" to Schema.boolean(
                description = "True only if a real financial trading chart (candlesticks, bars, or line price chart from a trading app or website) is clearly visible on the main screen."
            ),
            "signal" to Schema.enumeration(
                values = listOf("NO_CHART", "STRONG_BUY", "STRONG_SELL", "WAIT"),
                description = "NO_CHART when no trading chart is visible; STRONG_BUY for clear bullish setup; STRONG_SELL for clear bearish setup; WAIT if chart is visible but sideways/unclear."
            ),
            "assetPair" to Schema.string(
                description = "Visible trading instrument or pair (e.g. USD/MXN (OTC), EUR/USD, BTC/USDT), or 'Unknown' if unreadable.",
                nullable = true
            ),
            "timeframe" to Schema.string(
                description = "Visible chart timeframe (e.g. 1m, 5m, 15s), or 'Unknown' if not shown.",
                nullable = true
            ),
            "confidencePercent" to Schema.integer(
                description = "Integer confidence score from 0 to 100 based on candlestick momentum and structure."
            ),
            "indicatorSummary" to Schema.string(
                description = "Concise one-line technical summary covering visible trend, SMA/Bollinger/RSI/Volume/momentum clues."
            ),
            "rationale" to Schema.string(
                description = "Brief 1-2 sentence explanation of the candlestick price action and why this signal was chosen."
            )
        )
    )

    private val model by lazy {
        Firebase.ai.generativeModel(
            modelName = MODEL_NAME,
            generationConfig = generationConfig {
                temperature = 0.2f
                maxOutputTokens = 350
                responseMimeType = "application/json"
                responseSchema = this@ChartVisionAnalyzer.responseSchema
            }
        )
    }

    suspend fun analyzeScreen(
        rawScreenshot: Bitmap,
        overlayRectOnScreen: Rect?
    ): Result<ChartAnalysisResult> = withContext(Dispatchers.IO) {
        val preparedBitmap = prepareCleanBitmap(rawScreenshot, overlayRectOnScreen)
        try {
            val response = withTimeout(TIMEOUT_MS) {
                model.generateContent(
                    content {
                        image(preparedBitmap)
                        text(
                            """
                            You are Screen AI Pro, an expert real-time candlestick chart vision analyst.
                            Inspect this Android screen capture carefully (ignore any solid dark masked rectangle—that is your own HUD overlay).
                            1. Determine whether a financial trading chart (candlestick, Heikin-Ashi, bar, or price action chart from platforms like Quotex, Binomo, IQ Option, TradingView, Binance, MetaTrader, etc.) is currently open and visible on the screen. Note: trading apps like Quotex often display custom photo wallpapers behind semi-transparent candlesticks—if candlesticks, price levels, timer, or Buy/Sell (Up/Down) buttons are visible, treat hasTradingChart=true.
                            2. If the screen shows a phone home screen, settings, chat, or non-chart content, set hasTradingChart=false and signal=NO_CHART.
                            3. If a trading chart IS clearly visible, inspect the recent candles, wicks, support/resistance, momentum, and any visible moving averages, Bollinger Bands, RSI, Volume, or Stochastic indicators.
                            4. Output STRONG_BUY when bullish momentum/breakout/reversal is clearly favored, STRONG_SELL when bearish momentum/breakdown/rejection is clearly favored, or WAIT if candles are flat/indecisive.
                            5. Read the visible asset pair (e.g. USD/MXN (OTC), EUR/CAD) and timeframe if legible.
                            """.trimIndent()
                        )
                    }
                )
            }

            val jsonText = response.text
                ?: return@withContext Result.failure(
                    IllegalStateException("Gemini returned an empty response.")
                )

            val parsed = parseResponse(jsonText)
            Result.success(parsed)
        } catch (e: TimeoutCancellationException) {
            Log.e(TAG, "Chart vision analysis timed out after ${TIMEOUT_MS}ms", e)
            Result.failure(
                IllegalStateException("AI analysis timed out after 60 seconds. Retrying…")
            )
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.e(TAG, "Chart vision analysis failed", e)
            Result.failure(e)
        } finally {
            if (preparedBitmap !== rawScreenshot && !preparedBitmap.isRecycled) {
                preparedBitmap.recycle()
            }
        }
    }

    private fun prepareCleanBitmap(source: Bitmap, overlayRect: Rect?): Bitmap {
        val width = source.width
        val height = source.height
        val scale = minOf(1f, MAX_DIMENSION_PX.toFloat() / maxOf(width, height).toFloat())
        val targetW = (width * scale).toInt().coerceAtLeast(1)
        val targetH = (height * scale).toInt().coerceAtLeast(1)

        val scaled = Bitmap.createScaledBitmap(source, targetW, targetH, true)
        val mutable = if (scaled.isMutable) {
            scaled
        } else {
            scaled.copy(Bitmap.Config.ARGB_8888, true).also {
                if (scaled !== source) scaled.recycle()
            }
        }

        // Mask out the floating HUD bounding box so Gemini never evaluates its own preview thumbnail.
        if (overlayRect != null && !overlayRect.isEmpty) {
            val canvas = Canvas(mutable)
            val paint = Paint().apply {
                color = Color.parseColor("#090C12")
                style = Paint.Style.FILL
            }
            canvas.drawRect(
                overlayRect.left * scale,
                overlayRect.top * scale,
                overlayRect.right * scale,
                overlayRect.bottom * scale,
                paint
            )
        }
        return mutable
    }

    private fun parseResponse(jsonText: String): ChartAnalysisResult {
        val json = JSONObject(jsonText)
        val hasChart = json.optBoolean("hasTradingChart", false)
        val rawSignal = json.optString("signal", "NO_CHART")
        val signal = if (!hasChart) {
            ChartSignalType.NO_CHART
        } else {
            runCatching { ChartSignalType.valueOf(rawSignal) }
                .getOrDefault(ChartSignalType.WAIT)
        }

        val assetPair = json.optString("assetPair")
            .takeIf { it.isNotBlank() && it != "null" } ?: "Chart Detected"
        val timeframe = json.optString("timeframe")
            .takeIf { it.isNotBlank() && it != "null" } ?: "Live"
        val confidence = json.optInt("confidencePercent", 0).coerceIn(0, 100)
        val indicators = json.optString("indicatorSummary", "Price action & momentum check")
        val rationale = json.optString("rationale", "Analyzed visible candle structure.")

        return ChartAnalysisResult(
            hasTradingChart = hasChart,
            signal = signal,
            assetPair = assetPair,
            timeframe = timeframe,
            confidencePercent = confidence,
            indicatorSummary = indicators,
            rationale = rationale
        )
    }
}
