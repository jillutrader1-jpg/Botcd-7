package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val ObsidianBg = Color(0xFF090C12)
val CharcoalSurface = Color(0xFF111722)
val ElevatedCardSurface = Color(0xFF161E2E)
val SubtleBorder = Color(0xFF232E45)

val ElectricCyan = Color(0xFF00E5FF)
val BullishEmerald = Color(0xFF00E676)
val BearishCrimson = Color(0xFFFF3B5C)
val AmberGold = Color(0xFFFFB300)

val IceWhite = Color(0xFFF1F5F9)
val SteelMuted = Color(0xFF8B9BB4)
val DeepOnAccent = Color(0xFF041016)
