package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.VolumeUp
import androidx.compose.material.icons.outlined.NotificationsActive
import androidx.compose.material.icons.rounded.AutoGraph
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.ErrorOutline
import androidx.compose.material.icons.rounded.Layers
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.RecordVoiceOver
import androidx.compose.material.icons.rounded.Stop
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material.icons.rounded.WarningAmber
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.overlay.HudPhase
import com.example.ui.theme.AmberGold
import com.example.ui.theme.BearishCrimson
import com.example.ui.theme.BullishEmerald
import com.example.ui.theme.CharcoalSurface
import com.example.ui.theme.DeepOnAccent
import com.example.ui.theme.ElectricCyan
import com.example.ui.theme.ElevatedCardSurface
import com.example.ui.theme.ObsidianBg
import com.example.ui.theme.SteelMuted
import com.example.ui.theme.SubtleBorder
import com.example.ui.viewmodel.MainDashboardUiState
import com.example.voice.VoiceReadinessState

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ControlHubScreen(
    uiState: MainDashboardUiState,
    onLaunchHud: () -> Unit,
    onStopHud: () -> Unit,
    onRequestOverlayPermission: () -> Unit,
    onRequestNotificationPermission: () -> Unit,
    onTestVoice: () -> Unit,
    onOpenTtsSettings: () -> Unit,
    onVoiceToggle: (Boolean) -> Unit,
    onScanIntervalChange: (Int) -> Unit,
    onCooldownChange: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    val runtime = uiState.overlayRuntime
    val isRunning = runtime.isRunning

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(ObsidianBg),
        contentAlignment = Alignment.TopCenter
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 600.dp),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Brand Header
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(
                                    Brush.linearGradient(
                                        listOf(ElectricCyan, BullishEmerald)
                                    )
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.AutoGraph,
                                contentDescription = stringResource(R.string.app_name),
                                tint = DeepOnAccent,
                                modifier = Modifier.size(22.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = stringResource(R.string.app_name),
                                style = MaterialTheme.typography.headlineMedium,
                                color = MaterialTheme.colorScheme.onBackground
                            )
                            Text(
                                text = stringResource(R.string.engine_subtitle),
                                style = MaterialTheme.typography.bodyMedium,
                                color = SteelMuted
                            )
                        }
                    }

                    EngineStatusBadge(isRunning = isRunning, phase = runtime.phase)
                }
            }

            // Hero Engine Card
            item {
                val accentColor = when {
                    !isRunning -> ElectricCyan
                    runtime.phase == HudPhase.STRONG_BUY -> BullishEmerald
                    runtime.phase == HudPhase.STRONG_SELL ||
                        runtime.phase == HudPhase.NO_CHART ||
                        runtime.phase == HudPhase.COOLDOWN ||
                        runtime.phase == HudPhase.ERROR -> BearishCrimson
                    runtime.phase == HudPhase.WAIT -> AmberGold
                    else -> ElectricCyan
                }

                Card(
                    shape = MaterialTheme.shapes.large,
                    colors = CardDefaults.cardColors(containerColor = CharcoalSurface),
                    border = BorderStroke(1.dp, accentColor.copy(alpha = 0.45f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(
                                Brush.radialGradient(
                                    colors = listOf(
                                        accentColor.copy(alpha = 0.16f),
                                        Color.Transparent
                                    )
                                )
                            )
                            .padding(20.dp)
                    ) {
                        Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = if (isRunning) runtime.statusLabel else "HUD STANDBY",
                                    style = MaterialTheme.typography.labelLarge,
                                    color = accentColor
                                )
                                if (isRunning && runtime.cooldownRemainingSec > 0) {
                                    Text(
                                        text = "RESUME IN ${runtime.cooldownRemainingSec}s",
                                        style = MaterialTheme.typography.labelMedium,
                                        color = AmberGold
                                    )
                                } else if (runtime.lastAssetPair.isNotBlank()) {
                                    Text(
                                        text = "${runtime.lastAssetPair} • ${runtime.lastConfidence}%",
                                        style = MaterialTheme.typography.labelMedium,
                                        color = SteelMuted
                                    )
                                }
                            }

                            Text(
                                text = if (isRunning) {
                                    "Floating overlay is active. Switch to Chrome or your trading platform to monitor live candles."
                                } else if (uiState.allPermissionsReady) {
                                    "All permissions ready. Tap below to start screen capture and float Screen AI Pro over any trading chart."
                                } else {
                                    "Complete the system readiness checklist below before launching the floating AI chart HUD."
                                },
                                style = MaterialTheme.typography.bodyLarge,
                                color = MaterialTheme.colorScheme.onSurface
                            )

                            AnimatedVisibility(visible = !runtime.errorMessage.isNullOrBlank()) {
                                Surface(
                                    color = MaterialTheme.colorScheme.errorContainer,
                                    shape = MaterialTheme.shapes.small,
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Row(
                                        modifier = Modifier.padding(12.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Icon(
                                            imageVector = Icons.Rounded.ErrorOutline,
                                            contentDescription = null,
                                            tint = BearishCrimson,
                                            modifier = Modifier.size(18.dp)
                                        )
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text(
                                            text = runtime.errorMessage.orEmpty(),
                                            style = MaterialTheme.typography.bodyMedium,
                                            color = MaterialTheme.colorScheme.onErrorContainer
                                        )
                                    }
                                }
                            }

                            Button(
                                onClick = { if (isRunning) onStopHud() else onLaunchHud() },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (isRunning) BearishCrimson else ElectricCyan,
                                    contentColor = if (isRunning) Color.White else DeepOnAccent
                                ),
                                shape = MaterialTheme.shapes.medium,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(52.dp)
                                    .testTag("launch_hud_button")
                            ) {
                                Icon(
                                    imageVector = if (isRunning) Icons.Rounded.Stop else Icons.Rounded.PlayArrow,
                                    contentDescription = null,
                                    modifier = Modifier.size(20.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = stringResource(
                                        if (isRunning) R.string.btn_stop_hud else R.string.btn_launch_hud
                                    ),
                                    style = MaterialTheme.typography.titleMedium
                                )
                            }
                        }
                    }
                }
            }

            // System Readiness Checklist
            item {
                Text(
                    text = stringResource(R.string.section_readiness),
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.onBackground,
                    modifier = Modifier.padding(top = 4.dp)
                )
            }

            item {
                Card(
                    shape = MaterialTheme.shapes.large,
                    colors = CardDefaults.cardColors(containerColor = CharcoalSurface),
                    border = BorderStroke(1.dp, SubtleBorder),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        ReadinessRow(
                            icon = Icons.Rounded.Layers,
                            title = stringResource(R.string.perm_overlay_title),
                            description = stringResource(R.string.perm_overlay_desc),
                            isReady = uiState.hasOverlayPermission,
                            actionLabel = stringResource(R.string.status_missing),
                            testTag = "overlay_permission_button",
                            onAction = onRequestOverlayPermission
                        )

                        ReadinessRow(
                            icon = Icons.Outlined.NotificationsActive,
                            title = stringResource(R.string.perm_notif_title),
                            description = stringResource(R.string.perm_notif_desc),
                            isReady = uiState.hasNotificationPermission,
                            actionLabel = stringResource(R.string.status_missing),
                            testTag = "notification_permission_button",
                            onAction = onRequestNotificationPermission
                        )

                        val voiceReady = uiState.voiceReadiness is VoiceReadinessState.Ready
                        val voiceDetail = when (val vr = uiState.voiceReadiness) {
                            is VoiceReadinessState.Ready -> "Bengali voice active (${vr.localeTag})"
                            is VoiceReadinessState.LanguageMissing ->
                                "Install Bengali (bn-BD / bn-IN) speech data in Android TTS settings"
                            is VoiceReadinessState.Checking -> "Checking Bengali TTS engine…"
                            is VoiceReadinessState.Error -> vr.message
                        }

                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            ReadinessRow(
                                icon = Icons.Rounded.RecordVoiceOver,
                                title = stringResource(R.string.perm_voice_title),
                                description = voiceDetail,
                                isReady = voiceReady,
                                actionLabel = stringResource(R.string.btn_tts_settings),
                                testTag = "tts_settings_button",
                                onAction = onOpenTtsSettings
                            )

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.End
                            ) {
                                OutlinedButton(
                                    onClick = onTestVoice,
                                    border = BorderStroke(1.dp, ElectricCyan.copy(alpha = 0.5f)),
                                    modifier = Modifier
                                        .minimumInteractiveComponentSize()
                                        .testTag("test_voice_button")
                                ) {
                                    Icon(
                                        imageVector = Icons.AutoMirrored.Rounded.VolumeUp,
                                        contentDescription = null,
                                        tint = ElectricCyan,
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = stringResource(R.string.btn_test_voice),
                                        color = ElectricCyan,
                                        style = MaterialTheme.typography.labelLarge
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // Auto-Scan & Cooldown Settings
            item {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.padding(top = 4.dp)
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Tune,
                        contentDescription = null,
                        tint = ElectricCyan,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = stringResource(R.string.section_engine_settings),
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                }
            }

            item {
                Card(
                    shape = MaterialTheme.shapes.large,
                    colors = CardDefaults.cardColors(containerColor = CharcoalSurface),
                    border = BorderStroke(1.dp, SubtleBorder),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = stringResource(R.string.setting_voice_alerts),
                                    style = MaterialTheme.typography.bodyLarge,
                                    fontWeight = FontWeight.Medium
                                )
                                Text(
                                    text = "Speaks No Chart, Analyzing, Buy & Sell alerts",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = SteelMuted
                                )
                            }
                            Switch(
                                checked = uiState.preferences.voiceEnabled,
                                onCheckedChange = onVoiceToggle,
                                colors = SwitchDefaults.colors(
                                    checkedThumbColor = DeepOnAccent,
                                    checkedTrackColor = ElectricCyan
                                ),
                                modifier = Modifier.testTag("voice_toggle_switch")
                            )
                        }

                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text(
                                text = stringResource(R.string.setting_scan_interval),
                                style = MaterialTheme.typography.bodyMedium,
                                color = SteelMuted
                            )
                            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                listOf(3, 5, 10).forEach { sec ->
                                    val selected = uiState.preferences.scanIntervalSeconds == sec
                                    FilterChip(
                                        selected = selected,
                                        onClick = { onScanIntervalChange(sec) },
                                        label = {
                                            Text(
                                                text = "${sec}s",
                                                style = MaterialTheme.typography.labelLarge
                                            )
                                        },
                                        colors = FilterChipDefaults.filterChipColors(
                                            selectedContainerColor = ElectricCyan.copy(alpha = 0.2f),
                                            selectedLabelColor = ElectricCyan
                                        ),
                                        modifier = Modifier.testTag("scan_interval_${sec}s")
                                    )
                                }
                            }
                        }

                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text(
                                text = stringResource(R.string.setting_cooldown),
                                style = MaterialTheme.typography.bodyMedium,
                                color = SteelMuted
                            )
                            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                listOf(20, 35, 60).forEach { sec ->
                                    val selected = uiState.preferences.cooldownSeconds == sec
                                    FilterChip(
                                        selected = selected,
                                        onClick = { onCooldownChange(sec) },
                                        label = {
                                            Text(
                                                text = "${sec}s",
                                                style = MaterialTheme.typography.labelLarge
                                            )
                                        },
                                        colors = FilterChipDefaults.filterChipColors(
                                            selectedContainerColor = BullishEmerald.copy(alpha = 0.2f),
                                            selectedLabelColor = BullishEmerald
                                        ),
                                        modifier = Modifier.testTag("cooldown_${sec}s")
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun EngineStatusBadge(isRunning: Boolean, phase: HudPhase) {
    val color = when {
        !isRunning -> SteelMuted
        phase == HudPhase.STRONG_BUY -> BullishEmerald
        phase == HudPhase.STRONG_SELL || phase == HudPhase.NO_CHART || phase == HudPhase.ERROR -> BearishCrimson
        else -> ElectricCyan
    }
    Surface(
        color = ElevatedCardSurface,
        shape = RoundedCornerShape(50),
        border = BorderStroke(1.dp, color.copy(alpha = 0.45f))
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(8.dp)
                    .clip(CircleShape)
                    .background(color)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = if (isRunning) "ACTIVE" else "OFFLINE",
                style = MaterialTheme.typography.labelMedium,
                color = color
            )
        }
    }
}

@Composable
private fun ReadinessRow(
    icon: ImageVector,
    title: String,
    description: String,
    isReady: Boolean,
    actionLabel: String,
    testTag: String,
    onAction: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(MaterialTheme.shapes.medium)
            .background(ElevatedCardSurface)
            .padding(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = if (isReady) BullishEmerald else AmberGold,
            modifier = Modifier.size(22.dp)
        )
        Spacer(modifier = Modifier.width(12.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                style = MaterialTheme.typography.bodyLarge,
                fontWeight = FontWeight.Medium
            )
            Text(
                text = description,
                style = MaterialTheme.typography.bodyMedium,
                color = SteelMuted
            )
        }
        Spacer(modifier = Modifier.width(8.dp))
        if (isReady) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Rounded.CheckCircle,
                    contentDescription = stringResource(R.string.status_granted),
                    tint = BullishEmerald,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = stringResource(R.string.status_granted),
                    style = MaterialTheme.typography.labelMedium,
                    color = BullishEmerald
                )
            }
        } else {
            TextButton(
                onClick = onAction,
                modifier = Modifier
                    .minimumInteractiveComponentSize()
                    .testTag(testTag)
            ) {
                Icon(
                    imageVector = Icons.Rounded.WarningAmber,
                    contentDescription = null,
                    tint = AmberGold,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = actionLabel,
                    style = MaterialTheme.typography.labelLarge,
                    color = AmberGold
                )
            }
        }
    }
}
