package com.example.ui.theme

import android.app.Activity
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.unit.dp
import androidx.core.view.WindowCompat

private val ScreenAiDarkColorScheme = darkColorScheme(
    primary = ElectricCyan,
    onPrimary = DeepOnAccent,
    primaryContainer = ColorTokens.CyanContainer,
    onPrimaryContainer = ElectricCyan,
    secondary = BullishEmerald,
    onSecondary = DeepOnAccent,
    secondaryContainer = ColorTokens.EmeraldContainer,
    onSecondaryContainer = BullishEmerald,
    tertiary = AmberGold,
    onTertiary = DeepOnAccent,
    error = BearishCrimson,
    onError = IceWhite,
    errorContainer = ColorTokens.CrimsonContainer,
    onErrorContainer = BearishCrimson,
    background = ObsidianBg,
    onBackground = IceWhite,
    surface = CharcoalSurface,
    onSurface = IceWhite,
    surfaceVariant = ElevatedCardSurface,
    onSurfaceVariant = SteelMuted,
    outline = SubtleBorder,
    outlineVariant = SubtleBorder
)

private object ColorTokens {
    val CyanContainer = androidx.compose.ui.graphics.Color(0xFF0A2A36)
    val EmeraldContainer = androidx.compose.ui.graphics.Color(0xFF082D1E)
    val CrimsonContainer = androidx.compose.ui.graphics.Color(0xFF360E18)
}

val AppShapes = Shapes(
    small = RoundedCornerShape(8.dp),
    medium = RoundedCornerShape(14.dp),
    large = RoundedCornerShape(20.dp)
)

@Composable
fun ScreenAiProTheme(
    content: @Composable () -> Unit
) {
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as? Activity)?.window ?: return@SideEffect
            WindowCompat.getInsetsController(window, view).isAppearanceLightStatusBars = false
            WindowCompat.getInsetsController(window, view).isAppearanceLightNavigationBars = false
        }
    }

    MaterialTheme(
        colorScheme = ScreenAiDarkColorScheme,
        typography = Typography,
        shapes = AppShapes,
        content = content
    )
}
