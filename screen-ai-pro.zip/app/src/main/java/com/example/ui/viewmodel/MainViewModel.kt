package com.example.ui.viewmodel

import android.Manifest
import android.app.Application
import android.content.pm.PackageManager
import android.os.Build
import android.provider.Settings
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.AppDatabase
import com.example.data.local.EnginePreferences
import com.example.data.local.SignalRecordEntity
import com.example.data.local.SignalRepository
import com.example.data.local.UserPreferencesRepository
import com.example.overlay.OverlayRuntimeHub
import com.example.overlay.OverlayRuntimeState
import com.example.voice.BengaliVoiceCoach
import com.example.voice.VoiceReadinessState
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

enum class SignalFilter(val label: String) {
    ALL("All"),
    BUY("Buy"),
    SELL("Sell"),
    WAIT("Wait")
}

data class MainDashboardUiState(
    val hasOverlayPermission: Boolean = false,
    val hasNotificationPermission: Boolean = true,
    val voiceReadiness: VoiceReadinessState = VoiceReadinessState.Checking,
    val overlayRuntime: OverlayRuntimeState = OverlayRuntimeState(),
    val preferences: EnginePreferences = EnginePreferences(),
    val signals: List<SignalRecordEntity> = emptyList(),
    val selectedFilter: SignalFilter = SignalFilter.ALL
) {
    val allPermissionsReady: Boolean
        get() = hasOverlayPermission && hasNotificationPermission

    val filteredSignals: List<SignalRecordEntity>
        get() = when (selectedFilter) {
            SignalFilter.ALL -> signals
            SignalFilter.BUY -> signals.filter { it.signalType == "STRONG_BUY" }
            SignalFilter.SELL -> signals.filter { it.signalType == "STRONG_SELL" }
            SignalFilter.WAIT -> signals.filter { it.signalType == "WAIT" }
        }
}

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val appContext = application.applicationContext
    private val signalRepository = SignalRepository(
        AppDatabase.getInstance(appContext).signalRecordDao()
    )
    private val prefsRepository = UserPreferencesRepository(appContext)
    private val voiceCoach = BengaliVoiceCoach(appContext)

    private val _permissions = MutableStateFlow(readPermissions())
    private val _selectedFilter = MutableStateFlow(SignalFilter.ALL)

    val uiState: StateFlow<MainDashboardUiState> = combine(
        _permissions,
        voiceCoach.readiness,
        OverlayRuntimeHub.state,
        prefsRepository.preferences,
        signalRepository.allSignals,
        _selectedFilter
    ) { values ->
        val perms = values[0] as Pair<Boolean, Boolean>
        val voice = values[1] as VoiceReadinessState
        val runtime = values[2] as OverlayRuntimeState
        val prefs = values[3] as EnginePreferences
        @Suppress("UNCHECKED_CAST")
        val signals = values[4] as List<SignalRecordEntity>
        val filter = values[5] as SignalFilter

        MainDashboardUiState(
            hasOverlayPermission = perms.first,
            hasNotificationPermission = perms.second,
            voiceReadiness = voice,
            overlayRuntime = runtime,
            preferences = prefs,
            signals = signals,
            selectedFilter = filter
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5_000L),
        initialValue = MainDashboardUiState(
            hasOverlayPermission = _permissions.value.first,
            hasNotificationPermission = _permissions.value.second
        )
    )

    private fun readPermissions(): Pair<Boolean, Boolean> {
        val overlayGranted = Settings.canDrawOverlays(appContext)
        val notifGranted = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            ContextCompat.checkSelfPermission(
                appContext,
                Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
        } else {
            true
        }
        return overlayGranted to notifGranted
    }

    fun refreshSystemChecks() {
        _permissions.value = readPermissions()
        voiceCoach.refreshStatus()
    }

    fun testBengaliVoice() {
        voiceCoach.speakTestSample()
    }

    fun setVoiceEnabled(enabled: Boolean) {
        viewModelScope.launch { prefsRepository.setVoiceEnabled(enabled) }
    }

    fun setScanInterval(seconds: Int) {
        viewModelScope.launch { prefsRepository.setScanIntervalSeconds(seconds) }
    }

    fun setCooldownSeconds(seconds: Int) {
        viewModelScope.launch { prefsRepository.setCooldownSeconds(seconds) }
    }

    fun setSignalFilter(filter: SignalFilter) {
        _selectedFilter.value = filter
    }

    fun deleteSignal(id: Long) {
        viewModelScope.launch { signalRepository.deleteSignal(id) }
    }

    fun clearHistory() {
        viewModelScope.launch { signalRepository.clearAll() }
    }

    override fun onCleared() {
        voiceCoach.release()
        super.onCleared()
    }
}
