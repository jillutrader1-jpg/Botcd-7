# Screen AI Pro — Floating AI Trading Chart Analyzer

An Android floating-screen AI assistant that continuously monitors your device screen, detects open trading candlestick charts in real time using Gemini Vision, runs multi-indicator technical analysis, and speaks clear **Buy / Sell / No-Chart** guidance in **Bengali** via a draggable **Screen AI Pro** floating HUD—paired with a companion setup dashboard and signal history log.

---

## User Review & Critical Decisions

> [!IMPORTANT]
> **Confirmed Requirements from Clarification**
> - **Language & Voice**: Bengali (`bn-BD` / `bn-IN`) Text-to-Speech voice guidance paired with crisp English pro-HUD status labels (`SCREEN AI PRO`, `NO CHART`, `MONITORING MARKET`, `ANALYZING SMA...`, `STRONG BUY`, `STRONG SELL`, `AI OFF`), matching the reference video.
> - **Scanning Mode**: Auto-continuous scanning with an automatic post-signal cooldown (`AI OFF` resting phase) before resuming market monitoring.
> - **Floating Overlay Controls**: Compact, draggable floating HUD featuring the `SCREEN AI PRO` title, live `HH:mm:ss` clock, animated RGB/status border, live miniature screen preview, bottom status pill, and `X` close button.
> - **Companion App Screen**: Guided Permission Setup dashboard + persistent Signal History Log.

> [!NOTE]
> **Firebase AI Logic Provisioning Required**
> Real-time chart recognition and candlestick technical analysis will be powered by **Firebase AI Logic (`gemini-3.8-flash`)** with structured JSON output and Firebase App Check. During build execution, we will prompt you once to accept the Firebase setup terms so backend AI Logic & App Check are automatically provisioned (no manual API keys required).

---

## 1. Overview & Core Concept

- **What It Does**: When activated from the companion dashboard, **Screen AI Pro** launches a persistent floating overlay window over any app (such as Chrome, Quotex, Binomo, IQ Option, or TradingView). It captures screen frames via Android's `MediaProjection` API, previews the live screen inside the floating HUD, and periodically sends compressed frames to Gemini Vision to determine whether a candlestick chart is visible and evaluate trend, SMA, Bollinger Bands, Volume, RSI, and Stochastic signals.
- **Target Audience**: Mobile binary/forex/crypto traders who want hands-free, real-time Bengali audio alerts and a compact floating confirmation widget while keeping their trading platform full-screen.
- **Key Value**: Eliminates constant manual switching or guesswork by combining live screen observation, structured AI vision technical analysis, Bengali voice announcements, and automatic signal logging in one seamless workflow.

---

## 2. User Experience & Visual Design

### Key User Flows

1. **First Launch & Permission Readiness (Companion Dashboard)**
   - The user opens **Auto AI** (`Screen AI Pro`) and sees a dark quantitative-terminal dashboard with a top **Engine Status** hero card and a 3-step readiness checklist:
     1. **Display Over Other Apps** (`SYSTEM_ALERT_WINDOW`) — tap to open Android's overlay settings and grant permission.
     2. **Notifications** (`POST_NOTIFICATIONS` on Android 13+) — required to keep the foreground screen-monitoring service visible and reliable.
     3. **Bengali Voice Engine** (`TextToSpeech`) — automatic check for `bn-BD` / `bn-IN` voice readiness with a **"Test Bengali Voice"** button.
   - Once permissions are granted, tapping **Launch Screen AI Pro** triggers Android's native **Screen Capture** (`MediaProjection`) consent dialog, starts the foreground monitoring service, and spawns the floating overlay.

2. **Floating HUD Lifecycle (Over Chrome / Trading App)**
   - **Initializing (`INITIALIZING...`)**: Overlay appears with a cyan/RGB animated border and live screen preview.
   - **No Chart Visible (`NO CHART`)**: When the user is on the home screen or non-chart app, the border shifts to crimson/amber, status reads `NO CHART`, and the Bengali voice announces once: *"আমি কোন ট্রেডিং চার্ট দেখতে পাচ্ছি না, অনুগ্রহ করে একটি ট্রেডিং চার্ট খুলুন"*.
   - **Chart Detected & Analyzing**: As soon as a candlestick trading chart appears on screen, the voice announces: *"হ্যাঁ, আমি ট্রেডিং চার্ট দেখতে পাচ্ছি এবং বিশ্লেষণ করছি, অনুগ্রহ করে অপেক্ষা করুন"*. The glowing RGB border cycles smoothly while the status pill progresses through technical verification stages (`MONITORING MARKET` → `ANALYZING SMA...` → `ANALYZING BOLLINGER...` → `ANALYZING VOLUME...` → `ANALYZING RSI...` → `ANALYZING STOCHASTIC...`) alongside the live Gemini Vision inference.
   - **Signal Delivery (`STRONG BUY` / `STRONG SELL` / `WAIT`)**:
     - On **Strong Buy**: Border locks to vibrant **Emerald Green**, status reads `STRONG BUY`, and voice speaks *"নিশ্চিন্তে বাই ট্রেড করতে পারেন"*.
     - On **Strong Sell**: Border locks to vibrant **Crimson Red**, status reads `STRONG SELL`, and voice speaks *"নিশ্চিন্তে সেল ট্রেড করতে পারেন"*.
     - On **Unclear / Neutral**: Status reads `WAIT / NEUTRAL` and advises waiting before continuing to monitor.
   - **Cooldown (`AI OFF`)**: Immediately after delivering an actionable signal, the HUD enters a brief cooldown period (`AI OFF` with crimson indicator, matching the video) so the user can place and observe their trade without conflicting alerts, then automatically returns to monitoring.
   - **Drag & Close**: The user can drag the floating window anywhere on screen and tap the circular `X` button at bottom-right to stop capture and dismiss the HUD cleanly.

3. **Signal History Log (Second Tab)**
   - Every delivered signal (`STRONG BUY`, `STRONG SELL`, `WAIT`) is saved locally and displayed in a chronological history feed with filter chips (`All`, `Buy`, `Sell`), showing detected asset/pair (when readable on the chart), confidence score, indicator summary, and exact timestamp. Tapping an entry reveals the full AI reasoning breakdown.

### Visual Identity & Theme

- **Aesthetic Direction**: High-precision **Dark Quantitative Trading Terminal** — ultra-clean dark obsidian surfaces, luminous bullish/bearish status accents, crisp hairline borders, and zero visual clutter.
- **Color Palette**:
  - Background: Obsidian Slate (`#090C12`)
  - Surface / Cards: Elevated Charcoal (`#111722` and `#161E2E`)
  - Primary Accent (AI / Active): Electric Cyan (`#00E5FF`)
  - Bullish / Strong Buy: Neon Emerald (`#00E676`)
  - Bearish / Strong Sell / Alert: Vivid Crimson (`#FF3B5C`)
  - Caution / Analyzing: Amber Gold (`#FFB300`)
  - Primary Text: Crisp Ice White (`#F1F5F9`) & Secondary Steel (`#8B9BB4`)
- **Typography**:
  - *Display & Headers*: `Space Grotesk` (bold, technical character)
  - *Body & Controls*: `Inter` (high legibility on small screens)
  - *HUD Telemetry, Clocks & Badges*: `JetBrains Mono` with tabular numerals for rock-steady `HH:mm:ss` timestamps and confidence percentages.
- **Floating HUD Styling**:
  - Rounded dark glass container (`14dp` radius) framed by an animated 2.5dp RGB / status-reactive glowing border.
  - Top bar: `SCREEN AI PRO` monospace label + live `HH:mm:ss` cyan clock.
  - Center viewport: Live miniature screen mirror inside a crisp dark frame, plus subtle scanline/corner reticle pulse during analysis.
  - Bottom bar: High-contrast status pill (`NO CHART`, `ANALYZING RSI...`, `STRONG BUY`, `AI OFF`) + 40dp-visual / 48dp-touch-safe circular `X` dismiss button.

---

## 3. Key Product Decisions & Trade-Offs

- **Decision 1: Real AI Vision Analysis vs. Mocked Random Signals**
  - *Chosen Approach*: Use **Firebase AI Logic (`gemini-3.8-flash`)** with a strict JSON `responseSchema` to classify whether a trading chart is visible (`hasTradingChart`), extract visible pair/timeframe metadata, and return a technical signal (`STRONG_BUY`, `STRONG_SELL`, `WAIT`) with indicator notes.
  - *Why*: Ensures the app genuinely inspects what is on screen (home screen vs. actual candlestick chart) and produces grounded analysis rather than fake hardcoded timers.
  - *Trade-off*: Network latency (~1.5–4s per AI check) is masked naturally by cycling the indicator animation stages (`ANALYZING SMA...`, `BOLLINGER...`, `VOLUME...`, `RSI...`, `STOCHASTIC...`) while inference completes.

- **Decision 2: Device-Local Persistence (Room) vs. Cloud Sync**
  - *Chosen Approach*: Store signal history logs locally with **Room Database** and user preferences (cooldown duration, voice toggle) in **DataStore**.
  - *Why*: Signal logs are automatically derived from live screen-capture sessions on the device, and avoiding a mandatory Google Sign-In wall lets users launch the floating analyzer immediately after granting system permissions.
  - *Trade-off*: Logs remain private on the user's device rather than syncing across devices.

- **Decision 3: Self-Exclusion / Frame Cleanliness During Screen Capture**
  - *Chosen Approach*: Downscale captured frames cleanly (max 960px width) and crop/mask the floating overlay bounding box before sending frames to Gemini Vision, while keeping a throttled ~8 FPS bitmap stream for the HUD preview.
  - *Why*: Prevents recursive visual feedback (the overlay seeing itself in the video loop) from confusing chart detection, keeps Gemini payloads fast and well under size limits, and preserves battery.

- **Decision 4: Bengali TTS State-Change Debouncing**
  - *Chosen Approach*: Trigger Bengali TTS utterances strictly on meaningful state transitions (e.g., entering `NO_CHART` once, entering `ANALYZING` once when a chart appears, and announcing the final `STRONG_BUY` / `STRONG_SELL` signal) with cooldown protection.
  - *Why*: Prevents repetitive voice overlap if a user lingers on the home screen or while frames refresh continuously.

---

## 4. Technical Architecture & Data Strategy

### System Architecture Diagram

```
┌──────────────────────────────────────────────────────────────────────┐
│                       Companion Compose App                          │
│  ┌──────────────────────┐       ┌──────────────────────────────────┐ │
│  │   Setup & Control    │       │      Signal History Screen       │ │
│  │  (Permissions + HUD  │       │   (Filter Chips + Detail Sheet)  │ │
│  │   Launch & Settings) │       └────────────────┬─────────────────┘ │
│  └──────────┬───────────┘                        │                   │
└─────────────┼────────────────────────────────────┼───────────────────┘
              │ Start/Stop Service +               │ Flow<List<Signal>>
              │ MediaProjection Token              ▼
┌─────────────▼──────────────────────┐   ┌─────────────────────────────┐
│  ScreenAiForegroundService         │   │   Room SignalRepository     │
│  (foregroundServiceType=           │◄──┤  (SignalDao + AppDatabase)  │
│   mediaProjection)                 │   └─────────────────────────────┘
│                                    │
│  ┌──────────────────────────────┐  │   ┌─────────────────────────────┐
│  │  MediaProjection &           │  ├──►│  ChartVisionAnalyzer        │
│  │  ImageReader Frame Pipeline  │  │   │  (Firebase.ai               │
│  └──────────────┬───────────────┘  │   │   gemini-3.8-flash + JSON)  │
│                 │ Live Preview     │   └─────────────────────────────┘
│                 ▼                  │
│  ┌──────────────────────────────┐  │   ┌─────────────────────────────┐
│  │  FloatingHudOverlay          ├──┴──►│  BengaliVoiceCoach          │
│  │  (WindowManager + RGB Glow + │      │  (Android TextToSpeech      │
│  │   Draggable Preview + Close) │      │   bn-BD / bn-IN)            │
│  └──────────────────────────────┘  │   └─────────────────────────────┘
└────────────────────────────────────┘
```

### Data Model & State

- **Overlay State Machine (`HudStatus`)**:
  - `INITIALIZING` → Initial 1.5s warm-up after overlay attaches.
  - `NO_CHART` → Gemini reports no candlestick/trading chart visible on screen.
  - `MONITORING` → Chart visible or awaiting next scan window.
  - `ANALYZING(stage)` → Actively calling `gemini-3.8-flash` while cycling indicator labels (`SMA`, `BOLLINGER`, `VOLUME`, `RSI`, `STOCHASTIC`).
  - `SIGNAL_BUY` / `SIGNAL_SELL` / `SIGNAL_WAIT` → Final signal displayed with green/red/amber styling and spoken in Bengali.
  - `COOLDOWN(remainingSeconds)` → Displays `AI OFF` state post-signal before automatically resuming `MONITORING`.
- **Persisted Signal Record (`SignalRecord` Room Entity)**:
  - `id`, `timestamp`, `signalType` (`STRONG_BUY`, `STRONG_SELL`, `WAIT`), `assetPair` (e.g., `USD/MXN (OTC)` or `Unknown`), `confidencePercent`, `indicatorSummary`, `aiRationale`.
- **User Preferences (`DataStore`)**:
  - `cooldownSeconds` (default `35s`), `scanIntervalSeconds` (default `5s`), `voiceEnabled` (default `true`).

### Interactive Component & State Mapping

- **Permission & Launch Flow**: Checking `Settings.canDrawOverlays(context)` and `POST_NOTIFICATIONS` updates live readiness badges in the ViewModel; tapping Launch requests `MediaProjectionManager.createScreenCaptureIntent()`, registers `MediaProjection.Callback` before `createVirtualDisplay`, and promotes the service via `startForeground(..., FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)`.
- **Overlay Touch & Lifecycle**: Drag gestures update `WindowManager.LayoutParams` `(x, y)` coordinates smoothly; tapping `X` or stopping from the notification tears down `VirtualDisplay`, `ImageReader`, `MediaProjection`, TTS, and removes the overlay view cleanly.
- **Error Recovery**: If `MediaProjection` is revoked by the system status-bar chip or screen lock (`onStop()`), or if Firebase AI encounters a timeout/network error, the service cleanly resets HUD status, updates the shared service state flow for the dashboard, and surfaces authentic error messaging without crashing.
